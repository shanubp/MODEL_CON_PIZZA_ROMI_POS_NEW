
import 'package:flutter/material.dart';

class EmailWidget extends StatefulWidget {
  EmailWidget({Key? key}) : super(key: key);

  @override
  _EmailWidgetState createState() => _EmailWidgetState();
}

class _EmailWidgetState extends State<EmailWidget> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
