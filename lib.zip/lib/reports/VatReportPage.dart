import 'package:flutter/material.dart';

class VatReport extends StatefulWidget {
  const VatReport({Key? key}) : super(key: key);

  @override
  State<VatReport> createState() => _VatReportState();
}

class _VatReportState extends State<VatReport> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
