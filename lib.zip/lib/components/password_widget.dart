
import 'package:flutter/material.dart';

class PasswordWidget extends StatefulWidget {
  PasswordWidget({Key? key}) : super(key: key);

  @override
  _PasswordWidgetState createState() => _PasswordWidgetState();
}

class _PasswordWidgetState extends State<PasswordWidget> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
