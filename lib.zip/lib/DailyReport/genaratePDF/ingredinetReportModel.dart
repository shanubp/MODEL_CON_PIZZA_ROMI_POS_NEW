

import 'package:awafi_pos/backend/backend.dart';

class IncredientReportData {

  // final DateTime From;
  // final DateTime To;
  final List  ing;

  const IncredientReportData(  {

    // this.From,
    // this.To,
    required this.ing,


  });
}