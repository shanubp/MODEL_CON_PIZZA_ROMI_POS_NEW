

import 'package:awafi_pos/backend/backend.dart';

class ProductReportData {
  final List productWiseData;
  final DateTime From;
  final DateTime To;

  const ProductReportData( {
    required this.productWiseData,
    required this.From,
    required this.To,


  });
}




