

import 'package:awafi_pos/backend/backend.dart';

class CardReportData {
  final List card;
  final DateTime From;
  final DateTime To;

  // CardReportData(this.amex, this.mada, this.visa, this.master);

  CardReportData(  {
    required this. card,
    required this.From,
    required this.To


  });
}




